- Planar (2D) lattice structures are suitable for **practical** realizations of topological [[Quantum Error Correction|QER]] codes.
- Planar surface code hosting **one logical** qubit: No periodic boundary conditions!
![[Pasted image 20250823124916.jpg]]
### Characteristics
- Logical $X_L$ ($Z_L$) operators need to start over opposite smooth (rough) boundaries of the lattice respectively.
- Thus these are non-contractible strings starting and ending at boundaries (topological property)
- They fulfill the anticommutation relation $\{X_L^{(1)},Z_L^{(1)}\}=0$ and commute with all stabilizers.
- 4-qubit plaquette and vector stabilizers in the bulk
- Reduced 3-qubit $X$-type and $Z$-type stabilizers at the smooth and rough boundaries

Minimal surface codes of distance $d=3$ (one arbitrary error correctable):

![[Pasted image 20250823125659.jpg]]