[[Identity Gate]], [[X Gate]], [[Y Gate]] and [[Z Gate]] are Pauli Gates.

## Identities

$X^2 = Y^2 = Z^2 = -iXYZ = \mathbb{1}$
$ZX = iY = -XZ$
