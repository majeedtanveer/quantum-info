The Identity Gate is as follows:

$\mathbb{I} = \begin{pmatrix}  1 & 0 \\  0 & 1  \end{pmatrix}$

It does essentially nothing
## Identities
$X^2 = Y^2 = Z^2 = \mathbb{I}$