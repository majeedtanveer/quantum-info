Gates are unitary operations a.k.a. matrices. Thus the direction of the circuit and equation are opposite.

![[Pasted image 20250716142535.png]]