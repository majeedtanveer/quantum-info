The swap gate swaps two qubits and can be constructed by a concatenation of [[CNOT gate|CNOTs]].

![[SWAP gate.png]]