U is applied to the second qubit if and only if the first qubit is in state $|1 \rangle$. The [[CNOT gate]] is a Controlled-X Gate.

![[Controlled-U Gate.png|300]]