Single qubit measurements are a measurement of Z if not specified. Pauli measurements are projections into the eigenstates auf the Pauli Operator. It is also called measurement in the Z-basis or measurements in the computational basis.
The qubit wire ends with a measurement, unless a classical trigger is set with a classical bit from the measurement.

![[Measurement.png]]