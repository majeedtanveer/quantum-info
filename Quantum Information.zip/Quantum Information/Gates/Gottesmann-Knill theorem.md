> [!IMPORTANT] Quantum circuits of only Clifford Gates can be perfectly simulated efficiently, i. e. in polynomial time, on classical computers.

More precisely, circuits involving (i) preparation of qubits in computational basis, (ii) [[Clifford Gates]] and (iii) measurements in the computational basis.